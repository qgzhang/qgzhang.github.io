function [c,rad] = f_mycircle(A,B,C)

a = A-C;
b = B-C;

na = norm(a);
nb = norm(b);
aa = na^2*b - nb^2*a;

nab = norm(cross(a,b));
c_abc = cross(aa, cross(a,b));

rad = na*nb*norm(a-b) / (2*nab);
c = c_abc / (2*nab^2) + C;
end

